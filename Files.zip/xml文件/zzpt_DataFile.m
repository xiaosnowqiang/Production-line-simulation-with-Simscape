% Simscape(TM) Multibody(TM) version: 5.2

% This is a model data file derived from a Simscape Multibody Import XML file using the smimport function.
% The data in this file sets the block parameter values in an imported Simscape Multibody model.
% For more information on this file, see the smimport function help page in the Simscape Multibody documentation.
% You can modify numerical values, but avoid any other changes to this file.
% Do not add code to this file. Do not edit the physical units shown in comments.

%%%VariableName:smiData


%============= RigidTransform =============%

%Initialize the RigidTransform structure array by filling in null values.
smiData.RigidTransform(82).translation = [0.0 0.0 0.0];
smiData.RigidTransform(82).angle = 0.0;
smiData.RigidTransform(82).axis = [0.0 0.0 0.0];
smiData.RigidTransform(82).ID = '';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(1).translation = [-2.2204460492503131e-13 -176.00000000000011 44.000000000000007];  % mm
smiData.RigidTransform(1).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(1).axis = [-0.57735026918962584 -0.57735026918962584 -0.57735026918962584];
smiData.RigidTransform(1).ID = 'B[手爪装配体:手爪1-1:-:手爪装配体:手爪2-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(2).translation = [2.0000000000002842 -2.9999999999979838 -124.02652140935541];  % mm
smiData.RigidTransform(2).angle = 1.5707963267948932;  % rad
smiData.RigidTransform(2).axis = [3.2186895403017436e-15 -3.4542034091043101e-15 1];
smiData.RigidTransform(2).ID = 'F[手爪装配体:手爪1-1:-:手爪装配体:手爪2-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(3).translation = [-2.2204460492503131e-13 -176.00000000000011 44.000000000000007];  % mm
smiData.RigidTransform(3).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(3).axis = [0.57735026918962584 -0.57735026918962584 0.57735026918962584];
smiData.RigidTransform(3).ID = 'B[手爪装配体:手爪1-1:-:手爪装配体:手爪2-2]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(4).translation = [2 -3.0000000000009175 241.36263421948809];  % mm
smiData.RigidTransform(4).angle = 1.570796326794893;  % rad
smiData.RigidTransform(4).axis = [0 -2.3551386880256663e-16 1];
smiData.RigidTransform(4).ID = 'F[手爪装配体:手爪1-1:-:手爪装配体:手爪2-2]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(5).translation = [-60.000000000000057 0 -40.000000000000007];  % mm
smiData.RigidTransform(5).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(5).axis = [0.57735026918962584 0.57735026918962584 0.57735026918962584];
smiData.RigidTransform(5).ID = 'B[上下板装配体:伸缩重组1-1:-:上下板装配体:伸缩重组2-2]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(6).translation = [-2.3100682121725495 1.429614284768945 62.249289231422622];  % mm
smiData.RigidTransform(6).angle = 1.314169429835763e-16;  % rad
smiData.RigidTransform(6).axis = [-0.8448096565171217 0.5350669530586083 -2.9702182550076603e-17];
smiData.RigidTransform(6).ID = 'F[上下板装配体:伸缩重组1-1:-:上下板装配体:伸缩重组2-2]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(7).translation = [-60.000000000000057 0 -39.999999999999986];  % mm
smiData.RigidTransform(7).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(7).axis = [0.57735026918962584 0.57735026918962584 0.57735026918962584];
smiData.RigidTransform(7).ID = 'B[上下板装配体:伸缩重组1-2:-:上下板装配体:伸缩重组2-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(8).translation = [-2.3100682045124925 1.4296142882126404 66.893754775838943];  % mm
smiData.RigidTransform(8).angle = 1.5707963267948932;  % rad
smiData.RigidTransform(8).axis = [-5.5511151231258012e-17 -5.5511151231257827e-17 1];
smiData.RigidTransform(8).ID = 'F[上下板装配体:伸缩重组1-2:-:上下板装配体:伸缩重组2-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(9).translation = [7.6899317963799865 56.429614285865462 54.999999999999936];  % mm
smiData.RigidTransform(9).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(9).axis = [-0.57735026918962584 -0.57735026918962584 -0.57735026918962584];
smiData.RigidTransform(9).ID = 'B[上下板装配体:伸缩重组2-1:-:上下板装配体:伸缩重组2-2]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(10).translation = [-12.310068197812242 56.429614284482639 -225.85695599265472];  % mm
smiData.RigidTransform(10).angle = 2.0943951023931975;  % rad
smiData.RigidTransform(10).axis = [-0.57735026918962651 -0.57735026918962451 -0.57735026918962629];
smiData.RigidTransform(10).ID = 'F[上下板装配体:伸缩重组2-1:-:上下板装配体:伸缩重组2-2]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(11).translation = [1036 180.00000000000003 -485];  % mm
smiData.RigidTransform(11).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(11).axis = [-0.57735026918962584 -0.57735026918962584 0.57735026918962584];
smiData.RigidTransform(11).ID = 'B[上下板装配体:上下板零件-1:-:上下板装配体:伸缩重组1-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(12).translation = [15.00000001019373 -950.60098389745326 -40.000000015759952];  % mm
smiData.RigidTransform(12).angle = 2.0943951023931873;  % rad
smiData.RigidTransform(12).axis = [-0.57735026918962107 -0.57735026918962307 -0.57735026918963317];
smiData.RigidTransform(12).ID = 'F[上下板装配体:上下板零件-1:-:上下板装配体:伸缩重组1-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(13).translation = [1036 180.00000000000006 -34.999999999999922];  % mm
smiData.RigidTransform(13).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(13).axis = [-0.57735026918962584 -0.57735026918962584 0.57735026918962584];
smiData.RigidTransform(13).ID = 'B[上下板装配体:上下板零件-1:-:上下板装配体:伸缩重组1-2]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(14).translation = [14.99999998988983 -950.60098389951406 -39.999999999507963];  % mm
smiData.RigidTransform(14).angle = 2.0943951023931957;  % rad
smiData.RigidTransform(14).axis = [-0.57735026918962584 0.57735026918962584 0.57735026918962584];
smiData.RigidTransform(14).ID = 'F[上下板装配体:上下板零件-1:-:上下板装配体:伸缩重组1-2]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(15).translation = [1002.5 52.499999999999993 -30.000000000000028];  % mm
smiData.RigidTransform(15).angle = 3.4700229143358262e-16;  % rad
smiData.RigidTransform(15).axis = [0.73331677172371201 -0.67988713203642359 -8.6502923708092077e-17];
smiData.RigidTransform(15).ID = 'B[上下板装配体:上下板零件-1:-:上下板装配体:滚筒-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(16).translation = [-1.3963585843157489e-10 441.99999999993037 -1.9326762412674725e-10];  % mm
smiData.RigidTransform(16).angle = 2.0943951023931957;  % rad
smiData.RigidTransform(16).axis = [-0.57735026918962584 -0.57735026918962573 -0.57735026918962573];
smiData.RigidTransform(16).ID = 'F[上下板装配体:上下板零件-1:-:上下板装配体:滚筒-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(17).translation = [927.5 52.499999999999993 -30.000000000000028];  % mm
smiData.RigidTransform(17).angle = 3.1415926535897931;  % rad
smiData.RigidTransform(17).axis = [-1 9.1617833257449148e-33 -1.1796119636642286e-16];
smiData.RigidTransform(17).ID = 'B[上下板装配体:上下板零件-1:-:上下板装配体:滚筒-2]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(18).translation = [1.1065054650316597e-08 442.00000000008311 3.2969182939268649e-12];  % mm
smiData.RigidTransform(18).angle = 2.0943951023931828;  % rad
smiData.RigidTransform(18).axis = [0.57735026918962162 -0.57735026918962007 0.57735026918963572];
smiData.RigidTransform(18).ID = 'F[上下板装配体:上下板零件-1:-:上下板装配体:滚筒-2]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(19).translation = [857.49999999999966 52.499999999999993 -30.000000000000028];  % mm
smiData.RigidTransform(19).angle = 3.1415926535897931;  % rad
smiData.RigidTransform(19).axis = [-1 9.1617833257449148e-33 -1.1796119636642286e-16];
smiData.RigidTransform(19).ID = 'B[上下板装配体:上下板零件-1:-:上下板装配体:滚筒-3]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(20).translation = [1.1076906503149075e-08 442.00000000007947 9.7145402833120897e-11];  % mm
smiData.RigidTransform(20).angle = 2.0943951023931828;  % rad
smiData.RigidTransform(20).axis = [0.57735026918962162 -0.57735026918961996 0.57735026918963561];
smiData.RigidTransform(20).ID = 'F[上下板装配体:上下板零件-1:-:上下板装配体:滚筒-3]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(21).translation = [782.49999999999977 52.499999999999993 -30.000000000000028];  % mm
smiData.RigidTransform(21).angle = 3.1415926535897931;  % rad
smiData.RigidTransform(21).axis = [-1 9.1617833257449148e-33 -1.1796119636642286e-16];
smiData.RigidTransform(21).ID = 'B[上下板装配体:上下板零件-1:-:上下板装配体:滚筒-4]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(22).translation = [-9.9173291800980223e-09 442.00000000007941 -5.0914650273625739e-10];  % mm
smiData.RigidTransform(22).angle = 2.0943951023931828;  % rad
smiData.RigidTransform(22).axis = [0.57735026918962162 -0.57735026918961996 0.57735026918963561];
smiData.RigidTransform(22).ID = 'F[上下板装配体:上下板零件-1:-:上下板装配体:滚筒-4]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(23).translation = [707.49999999999977 52.499999999999993 -30.000000000000028];  % mm
smiData.RigidTransform(23).angle = 3.1415926535897931;  % rad
smiData.RigidTransform(23).axis = [-1 9.1617833257449148e-33 -1.1796119636642286e-16];
smiData.RigidTransform(23).ID = 'B[上下板装配体:上下板零件-1:-:上下板装配体:滚筒-5]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(24).translation = [-9.933557976182783e-09 442.00000000007782 -6.3693050833535381e-10];  % mm
smiData.RigidTransform(24).angle = 2.0943951023931833;  % rad
smiData.RigidTransform(24).axis = [0.57735026918962162 -0.57735026918962007 0.57735026918963572];
smiData.RigidTransform(24).ID = 'F[上下板装配体:上下板零件-1:-:上下板装配体:滚筒-5]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(25).translation = [632.49999999999989 52.499999999999993 -30.000000000000028];  % mm
smiData.RigidTransform(25).angle = 3.1415926535897931;  % rad
smiData.RigidTransform(25).axis = [-1 9.1617833257449148e-33 -1.1796119636642286e-16];
smiData.RigidTransform(25).ID = 'B[上下板装配体:上下板零件-1:-:上下板装配体:滚筒-6]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(26).translation = [-8.5364604274218436e-10 441.99999999993213 -3.5413449950283393e-11];  % mm
smiData.RigidTransform(26).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(26).axis = [0.57735026918962584 -0.57735026918962584 0.57735026918962584];
smiData.RigidTransform(26).ID = 'F[上下板装配体:上下板零件-1:-:上下板装配体:滚筒-6]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(27).translation = [557.49999999999989 52.499999999999993 -30.000000000000028];  % mm
smiData.RigidTransform(27).angle = 3.4700229143358262e-16;  % rad
smiData.RigidTransform(27).axis = [0.73331677172371201 -0.67988713203642359 -8.6502923708092077e-17];
smiData.RigidTransform(27).ID = 'B[上下板装配体:上下板零件-1:-:上下板装配体:滚筒-7]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(28).translation = [-8.333245204994455e-10 441.99999999993037 -3.7402969610411674e-11];  % mm
smiData.RigidTransform(28).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(28).axis = [-0.57735026918962584 -0.57735026918962584 -0.57735026918962584];
smiData.RigidTransform(28).ID = 'F[上下板装配体:上下板零件-1:-:上下板装配体:滚筒-7]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(29).translation = [482.49999999999994 52.499999999999908 -30.000000000000028];  % mm
smiData.RigidTransform(29).angle = 0;  % rad
smiData.RigidTransform(29).axis = [0 0 0];
smiData.RigidTransform(29).ID = 'B[上下板装配体:上下板零件-1:-:上下板装配体:滚筒-8]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(30).translation = [-6.4904526198006351e-10 441.99999999993031 -3.2457592169521376e-11];  % mm
smiData.RigidTransform(30).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(30).axis = [-0.57735026918962584 -0.57735026918962595 -0.57735026918962562];
smiData.RigidTransform(30).ID = 'F[上下板装配体:上下板零件-1:-:上下板装配体:滚筒-8]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(31).translation = [407.49999999999994 52.499999999999908 -30.000000000000028];  % mm
smiData.RigidTransform(31).angle = 3.1415926535897931;  % rad
smiData.RigidTransform(31).axis = [1 0 0];
smiData.RigidTransform(31).ID = 'B[上下板装配体:上下板零件-1:-:上下板装配体:滚筒-9]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(32).translation = [-6.3344884893012932e-10 441.99999999993202 -3.4731328923953697e-11];  % mm
smiData.RigidTransform(32).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(32).axis = [0.57735026918962584 -0.57735026918962584 0.57735026918962584];
smiData.RigidTransform(32).ID = 'F[上下板装配体:上下板零件-1:-:上下板装配体:滚筒-9]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(33).translation = [337.5 52.499999999999908 -30.000000000000028];  % mm
smiData.RigidTransform(33).angle = 3.1415926535897931;  % rad
smiData.RigidTransform(33).axis = [1 0 0];
smiData.RigidTransform(33).ID = 'B[上下板装配体:上下板零件-1:-:上下板装配体:滚筒-10]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(34).translation = [1.9504113879520446e-09 441.99999999993042 1.0930989446933381e-10];  % mm
smiData.RigidTransform(34).angle = 2.0943951023931957;  % rad
smiData.RigidTransform(34).axis = [0.57735026918962595 -0.57735026918962573 0.57735026918962562];
smiData.RigidTransform(34).ID = 'F[上下板装配体:上下板零件-1:-:上下板装配体:滚筒-10]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(35).translation = [262.5 52.499999999999908 -30.000000000000028];  % mm
smiData.RigidTransform(35).angle = 3.1415926535897931;  % rad
smiData.RigidTransform(35).axis = [1 0 0];
smiData.RigidTransform(35).ID = 'B[上下板装配体:上下板零件-1:-:上下板装配体:滚筒-11]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(36).translation = [1.8994228412338998e-09 441.99999999993196 1.1505107977427542e-10];  % mm
smiData.RigidTransform(36).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(36).axis = [0.57735026918962584 -0.57735026918962584 0.57735026918962584];
smiData.RigidTransform(36).ID = 'F[上下板装配体:上下板零件-1:-:上下板装配体:滚筒-11]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(37).translation = [187.5 52.499999999999908 -30.000000000000028];  % mm
smiData.RigidTransform(37).angle = 3.1415926535897931;  % rad
smiData.RigidTransform(37).axis = [1 0 0];
smiData.RigidTransform(37).ID = 'B[上下板装配体:上下板零件-1:-:上下板装配体:滚筒-12]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(38).translation = [-1.4706245110573946e-09 441.99999999993042 -9.5212726591853425e-11];  % mm
smiData.RigidTransform(38).angle = 2.0943951023931962;  % rad
smiData.RigidTransform(38).axis = [0.57735026918962595 -0.57735026918962595 0.5773502691896254];
smiData.RigidTransform(38).ID = 'F[上下板装配体:上下板零件-1:-:上下板装配体:滚筒-12]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(39).translation = [112.49999999999999 52.499999999999879 -30.000000000000028];  % mm
smiData.RigidTransform(39).angle = 3.1415926535897931;  % rad
smiData.RigidTransform(39).axis = [1 0 0];
smiData.RigidTransform(39).ID = 'B[上下板装配体:上下板零件-1:-:上下板装配体:滚筒-13]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(40).translation = [-5.6843418860808015e-14 441.99999999993037 6.2527760746888816e-13];  % mm
smiData.RigidTransform(40).angle = 2.0943951023931957;  % rad
smiData.RigidTransform(40).axis = [0.57735026918962573 -0.57735026918962595 0.57735026918962562];
smiData.RigidTransform(40).ID = 'F[上下板装配体:上下板零件-1:-:上下板装配体:滚筒-13]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(41).translation = [37.499999999999979 52.500000000000021 -30.000000000000028];  % mm
smiData.RigidTransform(41).angle = 0;  % rad
smiData.RigidTransform(41).axis = [0 0 0];
smiData.RigidTransform(41).ID = 'B[上下板装配体:上下板零件-1:-:上下板装配体:滚筒-14]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(42).translation = [-5.6843418860808015e-14 441.99999999993042 7.9580786405131221e-13];  % mm
smiData.RigidTransform(42).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(42).axis = [-0.57735026918962584 -0.57735026918962584 -0.57735026918962584];
smiData.RigidTransform(42).ID = 'F[上下板装配体:上下板零件-1:-:上下板装配体:滚筒-14]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(43).translation = [-659.64675355303712 0 50.000000000000711];  % mm
smiData.RigidTransform(43).angle = 0;  % rad
smiData.RigidTransform(43).axis = [0 0 0];
smiData.RigidTransform(43).ID = 'B[机器人大臂-1:-:机器人小臂重组-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(44).translation = [1.3372947194056906e-10 -49.999999999999339 -28.049066676287154];  % mm
smiData.RigidTransform(44).angle = 2.0943951023932041;  % rad
smiData.RigidTransform(44).axis = [-0.57735026918962851 -0.57735026918961962 -0.57735026918962906];
smiData.RigidTransform(44).ID = 'F[机器人大臂-1:-:机器人小臂重组-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(45).translation = [600.24924906612137 -85.000000000004405 -27.357120423008251];  % mm
smiData.RigidTransform(45).angle = 2.0943951023931997;  % rad
smiData.RigidTransform(45).axis = [-0.57735026918962729 -0.57735026918962251 -0.57735026918962762];
smiData.RigidTransform(45).ID = 'B[机器人小臂重组-1:-:末端重组-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(46).translation = [100.00000000005328 -15.000000000000959 -24.999999999937287];  % mm
smiData.RigidTransform(46).angle = 2.0943951023931957;  % rad
smiData.RigidTransform(46).axis = [0.57735026918962573 -0.57735026918962407 0.5773502691896274];
smiData.RigidTransform(46).ID = 'F[机器人小臂重组-1:-:末端重组-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(47).translation = [79.999999978717284 -7.999999891985965 150.00000000004621];  % mm
smiData.RigidTransform(47).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(47).axis = [0.57735026918962584 -0.57735026918962584 0.57735026918962584];
smiData.RigidTransform(47).ID = 'B[机器人腰部重组-1:-:机器人大臂-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(48).translation = [5.1059607930614703e-11 -2.1305898018075808e-11 41.999999919976005];  % mm
smiData.RigidTransform(48).angle = 3.1415926535897829;  % rad
smiData.RigidTransform(48).axis = [-1 2.6290447677723039e-29 -5.1264606843459712e-15];
smiData.RigidTransform(48).ID = 'F[机器人腰部重组-1:-:机器人大臂-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(49).translation = [-659.64675355303712 0 -22.499999999999076];  % mm
smiData.RigidTransform(49).angle = 0;  % rad
smiData.RigidTransform(49).axis = [0 0 0];
smiData.RigidTransform(49).ID = 'B[机器人大臂-1:-:三角架重组-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(50).translation = [-1.283453343603469e-10 -15.000000000002032 -81.947689404316208];  % mm
smiData.RigidTransform(50).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(50).axis = [-0.57735026918962562 -0.57735026918962506 -0.57735026918962662];
smiData.RigidTransform(50).ID = 'F[机器人大臂-1:-:三角架重组-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(51).translation = [2500 640.00000000000057 -1200.0000000000002];  % mm
smiData.RigidTransform(51).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(51).axis = [-0.57735026918962584 -0.57735026918962584 -0.57735026918962584];
smiData.RigidTransform(51).ID = 'B[架子重组-1:-:底部-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(52).translation = [-5.6843418860808015e-12 2499.9999999999545 -1960.0000000002156];  % mm
smiData.RigidTransform(52).angle = 1.5707963267948968;  % rad
smiData.RigidTransform(52).axis = [1.554312234475216e-15 -1 1.7763568394002528e-15];
smiData.RigidTransform(52).ID = 'F[架子重组-1:-:底部-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(53).translation = [0 -4520.0000000000009 -1200.0000000000007];  % mm
smiData.RigidTransform(53).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(53).axis = [0.57735026918962584 -0.57735026918962584 0.57735026918962584];
smiData.RigidTransform(53).ID = 'B[架子重组-2:-:底部-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(54).translation = [9.0039975475519896e-10 2.7966962079517543e-11 7754.9891308574934];  % mm
smiData.RigidTransform(54).angle = 3.1415926535897882;  % rad
smiData.RigidTransform(54).axis = [-0.70710678118654646 -9.8130778667740284e-17 0.70710678118654857];
smiData.RigidTransform(54).ID = 'F[架子重组-2:-:底部-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(55).translation = [147.05882352940242 -242.00000000005284 -249.99999999996092];  % mm
smiData.RigidTransform(55).angle = 2.0943951023932068;  % rad
smiData.RigidTransform(55).axis = [-0.57735026918962951 -0.57735026918962951 -0.57735026918961818];
smiData.RigidTransform(55).ID = 'B[机器人底部重组-1:-:机器人腰部重组-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(56).translation = [1.902362164714691e-07 1.8803218004848077e-07 -7.9999999998933635];  % mm
smiData.RigidTransform(56).angle = 3.1415926535897731;  % rad
smiData.RigidTransform(56).axis = [1 9.3214117668691524e-31 9.3397038539359386e-17];
smiData.RigidTransform(56).ID = 'F[机器人底部重组-1:-:机器人腰部重组-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(57).translation = [272.05882339063834 99.99999999994435 -419.99999999967133];  % mm
smiData.RigidTransform(57).angle = 2.0943951023932033;  % rad
smiData.RigidTransform(57).axis = [0.57735026918962451 0.5773502691896284 0.57735026918962451];
smiData.RigidTransform(57).ID = 'B[机器人底部重组-1:-:底部-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(58).translation = [2860.5555842038175 89.999999999940201 3106.6723551626565];  % mm
smiData.RigidTransform(58).angle = 3.1415926535897833;  % rad
smiData.RigidTransform(58).axis = [0.70710678118654269 -0.70710678118655235 -4.7739590058881731e-15];
smiData.RigidTransform(58).ID = 'F[机器人底部重组-1:-:底部-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(59).translation = [67.071067811865333 22.500000000004405 104.99999999999699];  % mm
smiData.RigidTransform(59).angle = 2.0943951023931899;  % rad
smiData.RigidTransform(59).axis = [0.57735026918962395 -0.57735026918962939 0.57735026918962395];
smiData.RigidTransform(59).ID = 'B[末端重组-1:-:小连杆-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(60).translation = [-602.5400000000277 -15.000000000067331 5.0000000000021343];  % mm
smiData.RigidTransform(60).angle = 5.8756641342446978e-15;  % rad
smiData.RigidTransform(60).axis = [0.94841391057113722 -0.31703478395148194 -8.833479312598526e-16];
smiData.RigidTransform(60).ID = 'F[末端重组-1:-:小连杆-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(61).translation = [-39.999999999999872 -49.999999999995381 -100.00000000000364];  % mm
smiData.RigidTransform(61).angle = 3.1415926535897931;  % rad
smiData.RigidTransform(61).axis = [1 0 2.3498345677285288e-15];
smiData.RigidTransform(61).ID = 'B[末端重组-1:-:末端连接-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(62).translation = [4.4160231027490227e-12 1.6541434888495132e-11 39.999999999963876];  % mm
smiData.RigidTransform(62).angle = 3.14159265358979;  % rad
smiData.RigidTransform(62).axis = [1 -2.9467665083448978e-30 -1.9206237682751814e-15];
smiData.RigidTransform(62).ID = 'F[末端重组-1:-:末端连接-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(63).translation = [106.16057790580832 -20.00000000000135 2.8310687127941492e-12];  % mm
smiData.RigidTransform(63).angle = 2.0943951023932033;  % rad
smiData.RigidTransform(63).axis = [-0.57735026918962828 -0.57735026918962407 -0.57735026918962495];
smiData.RigidTransform(63).ID = 'B[三角架重组-1:-:小连杆-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(64).translation = [-1.6248336009994091e-10 -14.99999999994713 3.1433449593221141e-12];  % mm
smiData.RigidTransform(64).angle = 8.0707161346551449e-15;  % rad
smiData.RigidTransform(64).axis = [0.43160119648121442 -0.90206452496259071 -1.571094544712859e-15];
smiData.RigidTransform(64).ID = 'F[三角架重组-1:-:小连杆-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(65).translation = [299.99999999999892 210.00000000000131 -99.999999999999204];  % mm
smiData.RigidTransform(65).angle = 2.0943951023931948;  % rad
smiData.RigidTransform(65).axis = [0.57735026918962651 0.57735026918962551 0.57735026918962518];
smiData.RigidTransform(65).ID = 'B[堆垛机组1-1:-:底部-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(66).translation = [1465.6625857226884 69.999999999760803 -79.99999999986926];  % mm
smiData.RigidTransform(66).angle = 1.5707963267948915;  % rad
smiData.RigidTransform(66).axis = [5.4400928206632718e-15 -1 5.4400928206632907e-15];
smiData.RigidTransform(66).ID = 'F[堆垛机组1-1:-:底部-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(67).translation = [384.99999999999977 300.00000000000006 27.999999999998693];  % mm
smiData.RigidTransform(67).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(67).axis = [0.57735026918962584 -0.57735026918962584 0.57735026918962584];
smiData.RigidTransform(67).ID = 'B[上下板装配体-1:上下板零件-1:-:堆垛机组1-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(68).translation = [224.99999999986659 304.99999999994952 1234.918399448416];  % mm
smiData.RigidTransform(68).angle = 3.1415926535897829;  % rad
smiData.RigidTransform(68).axis = [1.7208456881689926e-15 1 -0];
smiData.RigidTransform(68).ID = 'F[上下板装配体-1:上下板零件-1:-:堆垛机组1-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(69).translation = [385.00000000000023 300.00000000000006 278.00000000000045];  % mm
smiData.RigidTransform(69).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(69).axis = [-0.57735026918962584 -0.57735026918962584 -0.57735026918962584];
smiData.RigidTransform(69).ID = 'B[上下板装配体-2:上下板零件-1:-:堆垛机组1-2]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(70).translation = [-25.00000000000739 305.000000000027 759.61609836110506];  % mm
smiData.RigidTransform(70).angle = 3.14159265358979;  % rad
smiData.RigidTransform(70).axis = [5.1625370645069779e-15 -0 1];
smiData.RigidTransform(70).ID = 'F[上下板装配体-2:上下板零件-1:-:堆垛机组1-2]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(71).translation = [0 210.00000000000219 -99.999999999999204];  % mm
smiData.RigidTransform(71).angle = 2.0943951023931948;  % rad
smiData.RigidTransform(71).axis = [0.57735026918962618 0.57735026918962562 0.57735026918962562];
smiData.RigidTransform(71).ID = 'B[堆垛机组1-2:-:底部-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(72).translation = [1380.7064425593862 69.999999999880401 5874.9891308620008];  % mm
smiData.RigidTransform(72).angle = 1.5707963267948954;  % rad
smiData.RigidTransform(72).axis = [-5.1625370645069905e-15 1 5.273559366969488e-15];
smiData.RigidTransform(72).ID = 'F[堆垛机组1-2:-:底部-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(73).translation = [-24.748737341530713 24.748737341529157 9.9999999999999947];  % mm
smiData.RigidTransform(73).angle = 3.1415926535897931;  % rad
smiData.RigidTransform(73).axis = [1 0 0];
smiData.RigidTransform(73).ID = 'B[末端连接-1:-:手爪装配体-1:手爪1-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(74).translation = [-24.748737342486507 24.748737341506885 -10.000000000000034];  % mm
smiData.RigidTransform(74).angle = 1.5707963267949805;  % rad
smiData.RigidTransform(74).axis = [-7.8504622934185455e-17 -3.0458873722413945e-16 -1];
smiData.RigidTransform(74).ID = 'F[末端连接-1:-:手爪装配体-1:手爪1-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(75).translation = [-121.92605538295959 -77.499999810729747 91.388645644308923];  % mm
smiData.RigidTransform(75).angle = 2.0943951023932086;  % rad
smiData.RigidTransform(75).axis = [-0.57735026918963006 -0.57735026918962828 -0.57735026918961896];
smiData.RigidTransform(75).ID = 'B[机器人腰部重组-1:-:大连杆-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(76).translation = [-659.65872218577078 -14.99999809807116 1.2306436980580315e-09];  % mm
smiData.RigidTransform(76).angle = 1.0646383082704807e-14;  % rad
smiData.RigidTransform(76).axis = [-0.7071143739302963 -0.70709918836126895 2.6615957700624345e-15];
smiData.RigidTransform(76).ID = 'F[机器人腰部重组-1:-:大连杆-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(77).translation = [-193.63327142125448 -19.999999999997797 2.886579864025407e-12];  % mm
smiData.RigidTransform(77).angle = 2.0943951023932033;  % rad
smiData.RigidTransform(77).axis = [-0.57735026918962828 -0.57735026918962407 -0.57735026918962495];
smiData.RigidTransform(77).ID = 'B[三角架重组-1:-:大连杆-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(78).translation = [-0.0087221856145216492 -14.999998097978871 -1.2969486595793001e-12];  % mm
smiData.RigidTransform(78).angle = 8.0986648967384582e-15;  % rad
smiData.RigidTransform(78).axis = [-0.95934389085605765 -0.28223979003173966 1.0964175745804183e-15];
smiData.RigidTransform(78).ID = 'F[三角架重组-1:-:大连杆-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(79).translation = [-8.1061440171179555 14.076279372107079 252.50000000000071];  % mm
smiData.RigidTransform(79).angle = 2.0943951023931997;  % rad
smiData.RigidTransform(79).axis = [0.57735026918962506 -0.57735026918962695 0.57735026918962518];
smiData.RigidTransform(79).ID = 'AssemblyGround[手爪装配体-1:手爪1-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(80).translation = [-2917.9968864718776 -1202.7591573459695 12865.555584190733];  % mm
smiData.RigidTransform(80).angle = 1.5707963267949003;  % rad
smiData.RigidTransform(80).axis = [0 1 0];
smiData.RigidTransform(80).ID = 'RootGround[底部-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(81).translation = [-496 -205.55061134080898 1208.0000000000002];  % mm
smiData.RigidTransform(81).angle = 0;  % rad
smiData.RigidTransform(81).axis = [0 0 0];
smiData.RigidTransform(81).ID = 'AssemblyGround[上下板装配体-1:上下板零件-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(82).translation = [-496 -205.55061134080898 1208.0000000000002];  % mm
smiData.RigidTransform(82).angle = 0;  % rad
smiData.RigidTransform(82).axis = [0 0 0];
smiData.RigidTransform(82).ID = 'AssemblyGround[上下板装配体-2:上下板零件-1]';


%============= Solid =============%
%Center of Mass (CoM) %Moments of Inertia (MoI) %Product of Inertia (PoI)

%Initialize the Solid structure array by filling in null values.
smiData.Solid(18).mass = 0.0;
smiData.Solid(18).CoM = [0.0 0.0 0.0];
smiData.Solid(18).MoI = [0.0 0.0 0.0];
smiData.Solid(18).PoI = [0.0 0.0 0.0];
smiData.Solid(18).color = [0.0 0.0 0.0];
smiData.Solid(18).opacity = 0.0;
smiData.Solid(18).ID = '';

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(1).mass = 87.311458867230343;  % kg
smiData.Solid(1).CoM = [108.83602544696967 197.07488804336211 1205.4408486696339];  % mm
smiData.Solid(1).MoI = [72128243.10938774 72645866.2981603 1203171.8665820954];  % kg*mm^2
smiData.Solid(1).PoI = [-85726.219512684882 2943441.4312887606 63815.855362470145];  % kg*mm^2
smiData.Solid(1).color = [1 1 1];
smiData.Solid(1).opacity = 1;
smiData.Solid(1).ID = '堆垛机组1*:*默认';

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(2).mass = 8.6525739583558039;  % kg
smiData.Solid(2).CoM = [47.796677179805663 -0.41718243369710806 84.864535062084173];  % mm
smiData.Solid(2).MoI = [166310.71694228557 98400.910666470285 128939.32733254171];  % kg*mm^2
smiData.Solid(2).PoI = [-34.096371918920184 -26816.36654104527 -504.56143137139549];  % kg*mm^2
smiData.Solid(2).color = [1 1 1];
smiData.Solid(2).opacity = 1;
smiData.Solid(2).ID = '机器人腰部重组*:*默认';

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(3).mass = 2.5143086886955235;  % kg
smiData.Solid(3).CoM = [177.94324711433936 -16.00989570688445 -28.822462919161708];  % mm
smiData.Solid(3).MoI = [7928.1199366574847 106091.44946831308 109947.37811683916];  % kg*mm^2
smiData.Solid(3).PoI = [-66.098854047688903 280.79621588649115 15203.238023280923];  % kg*mm^2
smiData.Solid(3).color = [1 1 1];
smiData.Solid(3).opacity = 1;
smiData.Solid(3).ID = '机器人小臂重组*:*默认';

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(4).mass = 0.32433142343060045;  % kg
smiData.Solid(4).CoM = [-329.83023789890558 -15.000001036364456 10.000000054229874];  % mm
smiData.Solid(4).MoI = [28.404576474250451 10949.225520234959 10960.368317127155];  % kg*mm^2
smiData.Solid(4).PoI = [-3.4500875532960199e-07 -5.0027495241103261e-06 -4.2516544485105966e-05];  % kg*mm^2
smiData.Solid(4).color = [1 1 1];
smiData.Solid(4).opacity = 1;
smiData.Solid(4).ID = '大连杆*:*默认';

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(5).mass = 0.30646340707511027;  % kg
smiData.Solid(5).CoM = [2.000000000000016 49.979870051182566 -15.861606208940445];  % mm
smiData.Solid(5).MoI = [278.60545899976438 994.09809539542914 1254.0779336412008];  % kg*mm^2
smiData.Solid(5).PoI = [6.1619326398773469 0 0];  % kg*mm^2
smiData.Solid(5).color = [1 1 1];
smiData.Solid(5).opacity = 1;
smiData.Solid(5).ID = '手爪2*:*默认';

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(6).mass = 0.31287429007875905;  % kg
smiData.Solid(6).CoM = [2.8133148246529349 0.0098221498640122303 24.501459748562045];  % mm
smiData.Solid(6).MoI = [458.0192249593876 254.61784795427781 584.69883641144133];  % kg*mm^2
smiData.Solid(6).PoI = [0.085100781423406741 -17.907461032738048 0.078040769962731502];  % kg*mm^2
smiData.Solid(6).color = [1 1 1];
smiData.Solid(6).opacity = 1;
smiData.Solid(6).ID = '手爪1*:*默认';

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(7).mass = 1.9717691208134438;  % kg
smiData.Solid(7).CoM = [-10.361912893365488 -48.530515751881509 -27.663732432856335];  % mm
smiData.Solid(7).MoI = [5674.2863305235669 9395.0858579258402 8201.5126680773537];  % kg*mm^2
smiData.Solid(7).PoI = [-201.77665163978301 -255.87256894407537 -224.16836209903761];  % kg*mm^2
smiData.Solid(7).color = [1 1 1];
smiData.Solid(7).opacity = 1;
smiData.Solid(7).ID = '末端重组*:*默认';

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(8).mass = 141.43824000000726;  % kg
smiData.Solid(8).CoM = [1447.2637776035874 -1946.3975228493207 -612.6582909968331];  % mm
smiData.Solid(8).MoI = [370354374.14923388 155623283.306602 464877599.76528126];  % kg*mm^2
smiData.Solid(8).PoI = [-6643.1774905091333 -1644249.6213567876 -140943.53519102355];  % kg*mm^2
smiData.Solid(8).color = [0.792156862745098 0.81960784313725488 0.93333333333333335];
smiData.Solid(8).opacity = 1;
smiData.Solid(8).ID = '架子重组*:*默认';

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(9).mass = 29.51639535538834;  % kg
smiData.Solid(9).CoM = [205.92959839627071 -6.8131335766870498 -251.94272018246005];  % mm
smiData.Solid(9).MoI = [667297.03777228214 1201955.8290695262 864190.08994166681];  % kg*mm^2
smiData.Solid(9).PoI = [269.37762876944441 11819.933177603294 -59646.952754466511];  % kg*mm^2
smiData.Solid(9).color = [1 1 1];
smiData.Solid(9).opacity = 1;
smiData.Solid(9).ID = '机器人底部重组*:*默认';

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(10).mass = 6.8816594980338799;  % kg
smiData.Solid(10).CoM = [-310.72239148678932 -0.0034211784220438265 47.201928299825433];  % mm
smiData.Solid(10).MoI = [12962.721782476347 484929.60282892088 488253.13945017103];  % kg*mm^2
smiData.Solid(10).PoI = [0.06866285877266505 -6730.7952555043221 -0.50704996015106807];  % kg*mm^2
smiData.Solid(10).color = [1 1 1];
smiData.Solid(10).opacity = 1;
smiData.Solid(10).ID = '机器人大臂*:*默认';

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(11).mass = 0.26183126451707928;  % kg
smiData.Solid(11).CoM = [-32.467246074804144 -10.000001073181043 -23.655495345593405];  % mm
smiData.Solid(11).MoI = [115.82707266719709 1653.3765637100171 1558.4673113452634];  % kg*mm^2
smiData.Solid(11).PoI = [-9.9879615738153986e-07 55.903303894155556 2.9054244970015382e-06];  % kg*mm^2
smiData.Solid(11).color = [1 1 1];
smiData.Solid(11).opacity = 1;
smiData.Solid(11).ID = '三角架重组*:*默认';

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(12).mass = 0.29496784576911117;  % kg
smiData.Solid(12).CoM = [-301.27000000000021 -14.999999999999993 10.000000000000002];  % mm
smiData.Solid(12).MoI = [25.821579810532558 8267.0511829869938 8277.2695299825682];  % kg*mm^2
smiData.Solid(12).PoI = [0 0 0];  % kg*mm^2
smiData.Solid(12).color = [1 1 1];
smiData.Solid(12).opacity = 1;
smiData.Solid(12).ID = '小连杆*:*默认';

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(13).mass = 0.18683889268939455;  % kg
smiData.Solid(13).CoM = [0.017616438040860494 -0.017616438040860171 16.551433992086];  % mm
smiData.Solid(13).MoI = [142.16482090315759 142.16482090315753 239.69267203108731];  % kg*mm^2
smiData.Solid(13).PoI = [-0.038869578874885111 0.038869578874882439 -0.081516862888130412];  % kg*mm^2
smiData.Solid(13).color = [1 1 1];
smiData.Solid(13).opacity = 1;
smiData.Solid(13).ID = '末端连接*:*默认';

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(14).mass = 10207.355992829713;  % kg
smiData.Solid(14).CoM = [2861.083117167866 -48.27575911710327 2901.9019222890038];  % mm
smiData.Solid(14).MoI = [84306489502.050323 167810947205.69196 83525192207.08197];  % kg*mm^2
smiData.Solid(14).PoI = [31104.607646409986 -102343.48153819362 2783132.0273646344];  % kg*mm^2
smiData.Solid(14).color = [1 1 1];
smiData.Solid(14).opacity = 1;
smiData.Solid(14).ID = '底部*:*默认';

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(15).mass = 2.0821371669411546;  % kg
smiData.Solid(15).CoM = [-12.321688596506617 -462.51797624242914 55.081733116191387];  % mm
smiData.Solid(15).MoI = [188125.48940350726 1809.9552686391787 189779.1931591529];  % kg*mm^2
smiData.Solid(15).PoI = [-94.423714344497583 -2.3693204471888003 -21.857779824967178];  % kg*mm^2
smiData.Solid(15).color = [1 1 1];
smiData.Solid(15).opacity = 1;
smiData.Solid(15).ID = '伸缩重组2*:*默认';

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(16).mass = 0.15418826522201981;  % kg
smiData.Solid(16).CoM = [11.57187675038095 1.5603182103627971 -39.999995933653004];  % mm
smiData.Solid(16).MoI = [122.45841022158932 121.3759515460363 90.492006867716526];  % kg*mm^2
smiData.Solid(16).PoI = [0.00031737401499299284 4.9374878397743052e-06 -0.81103841860393056];  % kg*mm^2
smiData.Solid(16).color = [1 1 1];
smiData.Solid(16).opacity = 1;
smiData.Solid(16).ID = '伸缩重组1*:*默认';

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(17).mass = 1.1339892842397719;  % kg
smiData.Solid(17).CoM = [0 200.24468085106386 0];  % mm
smiData.Solid(17).MoI = [15477.025011226644 508.96213731312599 15477.025011226644];  % kg*mm^2
smiData.Solid(17).PoI = [0 0 0];  % kg*mm^2
smiData.Solid(17).color = [0.69999999999999996 0 0];
smiData.Solid(17).opacity = 1;
smiData.Solid(17).ID = '滚筒*:*默认';

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(18).mass = 20.832551282162566;  % kg
smiData.Solid(18).CoM = [499.38861463552729 107.97563781083622 -36.971580116884653];  % mm
smiData.Solid(18).MoI = [1564634.5210756371 2441410.3107450209 1238802.2654887862];  % kg*mm^2
smiData.Solid(18).PoI = [-195255.76839848995 43619.540791204599 20800.984974300118];  % kg*mm^2
smiData.Solid(18).color = [1 1 1];
smiData.Solid(18).opacity = 1;
smiData.Solid(18).ID = '上下板零件*:*默认';


%============= Joint =============%
%X Revolute Primitive (Rx) %Y Revolute Primitive (Ry) %Z Revolute Primitive (Rz)
%X Prismatic Primitive (Px) %Y Prismatic Primitive (Py) %Z Prismatic Primitive (Pz) %Spherical Primitive (S)
%Constant Velocity Primitive (CV) %Lead Screw Primitive (LS)
%Position Target (Pos)

%Initialize the CylindricalJoint structure array by filling in null values.
smiData.CylindricalJoint(4).Rz.Pos = 0.0;
smiData.CylindricalJoint(4).Pz.Pos = 0.0;
smiData.CylindricalJoint(4).ID = '';

smiData.CylindricalJoint(1).Rz.Pos = -89.999999999998991;  % deg
smiData.CylindricalJoint(1).Pz.Pos = 0;  % mm
smiData.CylindricalJoint(1).ID = '[上下板装配体-1:伸缩重组1-1:-:上下板装配体-1:伸缩重组2-2]';

smiData.CylindricalJoint(2).Rz.Pos = -89.999999999998991;  % deg
smiData.CylindricalJoint(2).Pz.Pos = 0;  % mm
smiData.CylindricalJoint(2).ID = '[上下板装配体-2:伸缩重组1-1:-:上下板装配体-2:伸缩重组2-2]';

%This joint has been chosen as a cut joint. Simscape Multibody treats cut joints as algebraic constraints to solve closed kinematic loops. The imported model does not use the state target data for this joint.
smiData.CylindricalJoint(3).Rz.Pos = -70.891532188051983;  % deg
smiData.CylindricalJoint(3).Pz.Pos = 0;  % mm
smiData.CylindricalJoint(3).ID = '[三角架重组-1:-:小连杆-1]';

%This joint has been chosen as a cut joint. Simscape Multibody treats cut joints as algebraic constraints to solve closed kinematic loops. The imported model does not use the state target data for this joint.
smiData.CylindricalJoint(4).Rz.Pos = 26.560005432379533;  % deg
smiData.CylindricalJoint(4).Pz.Pos = 0;  % mm
smiData.CylindricalJoint(4).ID = '[三角架重组-1:-:大连杆-1]';


%Initialize the PlanarJoint structure array by filling in null values.
smiData.PlanarJoint(2).Rz.Pos = 0.0;
smiData.PlanarJoint(2).Px.Pos = 0.0;
smiData.PlanarJoint(2).Py.Pos = 0.0;
smiData.PlanarJoint(2).ID = '';

%This joint has been chosen as a cut joint. Simscape Multibody treats cut joints as algebraic constraints to solve closed kinematic loops. The imported model does not use the state target data for this joint.
smiData.PlanarJoint(1).Rz.Pos = -179.99999999999983;  % deg
smiData.PlanarJoint(1).Px.Pos = 0;  % mm
smiData.PlanarJoint(1).Py.Pos = 0;  % mm
smiData.PlanarJoint(1).ID = '[上下板装配体-1:伸缩重组2-1:-:上下板装配体-1:伸缩重组2-2]';

%This joint has been chosen as a cut joint. Simscape Multibody treats cut joints as algebraic constraints to solve closed kinematic loops. The imported model does not use the state target data for this joint.
smiData.PlanarJoint(2).Rz.Pos = -179.99999999999983;  % deg
smiData.PlanarJoint(2).Px.Pos = 0;  % mm
smiData.PlanarJoint(2).Py.Pos = 0;  % mm
smiData.PlanarJoint(2).ID = '[上下板装配体-2:伸缩重组2-1:-:上下板装配体-2:伸缩重组2-2]';


%Initialize the PrismaticJoint structure array by filling in null values.
smiData.PrismaticJoint(13).Pz.Pos = 0.0;
smiData.PrismaticJoint(13).ID = '';

smiData.PrismaticJoint(1).Pz.Pos = 0;  % m
smiData.PrismaticJoint(1).ID = '[手爪装配体-1:手爪1-1:-:手爪装配体-1:手爪2-1]';

smiData.PrismaticJoint(2).Pz.Pos = 0;  % m
smiData.PrismaticJoint(2).ID = '[手爪装配体-1:手爪1-1:-:手爪装配体-1:手爪2-2]';

smiData.PrismaticJoint(3).Pz.Pos = 0;  % m
smiData.PrismaticJoint(3).ID = '[上下板装配体-1:伸缩重组1-2:-:上下板装配体-1:伸缩重组2-1]';

smiData.PrismaticJoint(4).Pz.Pos = 0;  % m
smiData.PrismaticJoint(4).ID = '[上下板装配体-1:上下板零件-1:-:上下板装配体-1:伸缩重组1-1]';

smiData.PrismaticJoint(5).Pz.Pos = 0;  % m
smiData.PrismaticJoint(5).ID = '[上下板装配体-1:上下板零件-1:-:上下板装配体-1:伸缩重组1-2]';

smiData.PrismaticJoint(6).Pz.Pos = 0;  % m
smiData.PrismaticJoint(6).ID = '[上下板装配体-2:伸缩重组1-2:-:上下板装配体-2:伸缩重组2-1]';

smiData.PrismaticJoint(7).Pz.Pos = 0;  % m
smiData.PrismaticJoint(7).ID = '[上下板装配体-2:上下板零件-1:-:上下板装配体-2:伸缩重组1-1]';

smiData.PrismaticJoint(8).Pz.Pos = 0;  % m
smiData.PrismaticJoint(8).ID = '[上下板装配体-2:上下板零件-1:-:上下板装配体-2:伸缩重组1-2]';

smiData.PrismaticJoint(9).Pz.Pos = 0;  % m
smiData.PrismaticJoint(9).ID = '[机器人底部重组-1:-:底部-1]';

smiData.PrismaticJoint(10).Pz.Pos = 0;  % m
smiData.PrismaticJoint(10).ID = '[堆垛机组1-1:-:底部-1]';

smiData.PrismaticJoint(11).Pz.Pos = 0;  % m
smiData.PrismaticJoint(11).ID = '[上下板装配体-1:上下板零件-1:-:堆垛机组1-1]';

smiData.PrismaticJoint(12).Pz.Pos = 0;  % m
smiData.PrismaticJoint(12).ID = '[上下板装配体-2:上下板零件-1:-:堆垛机组1-2]';

smiData.PrismaticJoint(13).Pz.Pos = 0;  % m
smiData.PrismaticJoint(13).ID = '[堆垛机组1-2:-:底部-1]';


%Initialize the RevoluteJoint structure array by filling in null values.
smiData.RevoluteJoint(36).Rz.Pos = 0.0;
smiData.RevoluteJoint(36).ID = '';

smiData.RevoluteJoint(1).Rz.Pos = 45.827466896446936;  % deg
smiData.RevoluteJoint(1).ID = '[上下板装配体-1:上下板零件-1:-:上下板装配体-1:滚筒-1]';

smiData.RevoluteJoint(2).Rz.Pos = 7.2583995619697754;  % deg
smiData.RevoluteJoint(2).ID = '[上下板装配体-1:上下板零件-1:-:上下板装配体-1:滚筒-2]';

smiData.RevoluteJoint(3).Rz.Pos = 7.2583995616210935;  % deg
smiData.RevoluteJoint(3).ID = '[上下板装配体-1:上下板零件-1:-:上下板装配体-1:滚筒-3]';

smiData.RevoluteJoint(4).Rz.Pos = 7.2583995612694734;  % deg
smiData.RevoluteJoint(4).ID = '[上下板装配体-1:上下板零件-1:-:上下板装配体-1:滚筒-4]';

smiData.RevoluteJoint(5).Rz.Pos = 7.258399561270612;  % deg
smiData.RevoluteJoint(5).ID = '[上下板装配体-1:上下板零件-1:-:上下板装配体-1:滚筒-5]';

smiData.RevoluteJoint(6).Rz.Pos = 7.2583995614437784;  % deg
smiData.RevoluteJoint(6).ID = '[上下板装配体-1:上下板零件-1:-:上下板装配体-1:滚筒-6]';

smiData.RevoluteJoint(7).Rz.Pos = -7.2583995614439614;  % deg
smiData.RevoluteJoint(7).ID = '[上下板装配体-1:上下板零件-1:-:上下板装配体-1:滚筒-7]';

smiData.RevoluteJoint(8).Rz.Pos = -7.2583995614437784;  % deg
smiData.RevoluteJoint(8).ID = '[上下板装配体-1:上下板零件-1:-:上下板装配体-1:滚筒-8]';

smiData.RevoluteJoint(9).Rz.Pos = 7.2583995614435626;  % deg
smiData.RevoluteJoint(9).ID = '[上下板装配体-1:上下板零件-1:-:上下板装配体-1:滚筒-9]';

smiData.RevoluteJoint(10).Rz.Pos = 7.2583995614505552;  % deg
smiData.RevoluteJoint(10).ID = '[上下板装配体-1:上下板零件-1:-:上下板装配体-1:滚筒-10]';

smiData.RevoluteJoint(11).Rz.Pos = 7.258399561452153;  % deg
smiData.RevoluteJoint(11).ID = '[上下板装配体-1:上下板零件-1:-:上下板装配体-1:滚筒-11]';

smiData.RevoluteJoint(12).Rz.Pos = 7.2583995616367893;  % deg
smiData.RevoluteJoint(12).ID = '[上下板装配体-1:上下板零件-1:-:上下板装配体-1:滚筒-12]';

smiData.RevoluteJoint(13).Rz.Pos = 7.2583995614938379;  % deg
smiData.RevoluteJoint(13).ID = '[上下板装配体-1:上下板零件-1:-:上下板装配体-1:滚筒-13]';

smiData.RevoluteJoint(14).Rz.Pos = -7.258399561493758;  % deg
smiData.RevoluteJoint(14).ID = '[上下板装配体-1:上下板零件-1:-:上下板装配体-1:滚筒-14]';

smiData.RevoluteJoint(15).Rz.Pos = 45.827466896446936;  % deg
smiData.RevoluteJoint(15).ID = '[上下板装配体-2:上下板零件-1:-:上下板装配体-2:滚筒-1]';

smiData.RevoluteJoint(16).Rz.Pos = 7.2583995619697896;  % deg
smiData.RevoluteJoint(16).ID = '[上下板装配体-2:上下板零件-1:-:上下板装配体-2:滚筒-2]';

smiData.RevoluteJoint(17).Rz.Pos = 7.2583995616210135;  % deg
smiData.RevoluteJoint(17).ID = '[上下板装配体-2:上下板零件-1:-:上下板装配体-2:滚筒-3]';

smiData.RevoluteJoint(18).Rz.Pos = 7.258399561269445;  % deg
smiData.RevoluteJoint(18).ID = '[上下板装配体-2:上下板零件-1:-:上下板装配体-2:滚筒-4]';

smiData.RevoluteJoint(19).Rz.Pos = 7.2583995612705454;  % deg
smiData.RevoluteJoint(19).ID = '[上下板装配体-2:上下板零件-1:-:上下板装配体-2:滚筒-5]';

smiData.RevoluteJoint(20).Rz.Pos = 7.2583995614437784;  % deg
smiData.RevoluteJoint(20).ID = '[上下板装配体-2:上下板零件-1:-:上下板装配体-2:滚筒-6]';

smiData.RevoluteJoint(21).Rz.Pos = -7.2583995614439614;  % deg
smiData.RevoluteJoint(21).ID = '[上下板装配体-2:上下板零件-1:-:上下板装配体-2:滚筒-7]';

smiData.RevoluteJoint(22).Rz.Pos = -7.2583995614437784;  % deg
smiData.RevoluteJoint(22).ID = '[上下板装配体-2:上下板零件-1:-:上下板装配体-2:滚筒-8]';

smiData.RevoluteJoint(23).Rz.Pos = 7.2583995614435626;  % deg
smiData.RevoluteJoint(23).ID = '[上下板装配体-2:上下板零件-1:-:上下板装配体-2:滚筒-9]';

smiData.RevoluteJoint(24).Rz.Pos = 7.2583995614505552;  % deg
smiData.RevoluteJoint(24).ID = '[上下板装配体-2:上下板零件-1:-:上下板装配体-2:滚筒-10]';

smiData.RevoluteJoint(25).Rz.Pos = 7.258399561452153;  % deg
smiData.RevoluteJoint(25).ID = '[上下板装配体-2:上下板零件-1:-:上下板装配体-2:滚筒-11]';

smiData.RevoluteJoint(26).Rz.Pos = 7.2583995616367893;  % deg
smiData.RevoluteJoint(26).ID = '[上下板装配体-2:上下板零件-1:-:上下板装配体-2:滚筒-12]';

smiData.RevoluteJoint(27).Rz.Pos = 7.2583995614938379;  % deg
smiData.RevoluteJoint(27).ID = '[上下板装配体-2:上下板零件-1:-:上下板装配体-2:滚筒-13]';

smiData.RevoluteJoint(28).Rz.Pos = -7.258399561493758;  % deg
smiData.RevoluteJoint(28).ID = '[上下板装配体-2:上下板零件-1:-:上下板装配体-2:滚筒-14]';

smiData.RevoluteJoint(29).Rz.Pos = 172.46745016341026;  % deg
smiData.RevoluteJoint(29).ID = '[机器人大臂-1:-:机器人小臂重组-1]';

smiData.RevoluteJoint(30).Rz.Pos = 20.27324994471644;  % deg
smiData.RevoluteJoint(30).ID = '[机器人小臂重组-1:-:末端重组-1]';

smiData.RevoluteJoint(31).Rz.Pos = -167.43628847423608;  % deg
smiData.RevoluteJoint(31).ID = '[机器人腰部重组-1:-:机器人大臂-1]';

smiData.RevoluteJoint(32).Rz.Pos = 153.44000881754246;  % deg
smiData.RevoluteJoint(32).ID = '[机器人大臂-1:-:三角架重组-1]';

smiData.RevoluteJoint(33).Rz.Pos = 90.051937320644981;  % deg
smiData.RevoluteJoint(33).ID = '[机器人底部重组-1:-:机器人腰部重组-1]';

smiData.RevoluteJoint(34).Rz.Pos = -110.19222347863624;  % deg
smiData.RevoluteJoint(34).ID = '[末端重组-1:-:小连杆-1]';

smiData.RevoluteJoint(35).Rz.Pos = 90.2048358163415;  % deg
smiData.RevoluteJoint(35).ID = '[末端重组-1:-:末端连接-1]';

smiData.RevoluteJoint(36).Rz.Pos = -12.563697275841932;  % deg
smiData.RevoluteJoint(36).ID = '[机器人腰部重组-1:-:大连杆-1]';

