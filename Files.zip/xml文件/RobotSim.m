function varargout = RobotSim(varargin)
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @RobotSim_OpeningFcn, ...
                   'gui_OutputFcn',  @RobotSim_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end
if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT

% --- Executes just before RobotSim is made visible.
function RobotSim_OpeningFcn(hObject, eventdata, handles, varargin)
handles.output = hObject;
guidata(hObject, handles);
handles.output = hObject;
h=timer;   %��ʱ��
handles.he=h;   %����ʱ���ŵ�ȫ�ֱ�����
%set(handles.he,'ExecutionMode','singleShot');  %��ʱ��ִֻ��һ�Σ���һ��ʱ��
set(handles.he,'ExecutionMode','fixedRate');   %��ʱ����ѭ��ִ�У�ѭ����ʱ��
set(handles.he,'Period',1);    %��ʱ������ʱ��� 1��
set(handles.he,'TimerFcn',{@disptime,handles});    %��ʱ������ʱ�ᴥ�� TimerFcn ��������ʱ����(TimerFcn)�����û��Զ���ĺ���(disptime����)
start(handles.he);   %������ʱ��
guidata(hObject, handles);
% �Զ���ĺ�������edit�ؼ������ݸĳɵ�ǰʱ�䡣��ʱ������ʱ�ᴥ���ú���
function disptime(hObject, eventdata, handles)
set(handles.edit26,'String',datestr(now));   % ��edit�ؼ������ݸĳɵ�ǰʱ��

% --- Outputs from this function are returned to the command line.
function varargout = RobotSim_OutputFcn(hObject, eventdata, handles) 
varargout{1} = handles.output;
% --- Executes on button press in pushbutton1.
function pushbutton1_Callback(hObject, eventdata, handles)
ModelName = 'zzpt';
% Opens the Simulink model 
open_system(ModelName);
set_param(ModelName,'BlockReduction','off');
set_param(ModelName,'StopTime','inf');
set_param(ModelName,'simulationMode','normal');
set_param(ModelName, 'SimulationCommand', 'start');


% --- Executes on button press in pushbutton2.
function pushbutton2_Callback(hObject, eventdata, handles)
ModelName = 'zzpt';
set_param(ModelName, 'SimulationCommand', 'stop');


% --- Executes on slider movement.
function slider1_Callback(hObject, eventdata, handles)
% hObject    handle to slider1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider


% --- Executes during object creation, after setting all properties.
function slider1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to slider1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end


% --- Executes on slider movement.
function slider2_Callback(hObject, eventdata, handles)
% hObject    handle to slider2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider


% --- Executes during object creation, after setting all properties.
function slider2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to slider2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end


% --- Executes on slider movement.
function slider3_Callback(hObject, eventdata, handles)
% hObject    handle to slider3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider


% --- Executes during object creation, after setting all properties.
function slider3_CreateFcn(hObject, eventdata, handles)
% hObject    handle to slider3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end


% --- Executes on slider movement.
function slider4_Callback(hObject, eventdata, handles)
% hObject    handle to slider4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider


% --- Executes during object creation, after setting all properties.
function slider4_CreateFcn(hObject, eventdata, handles)
% hObject    handle to slider4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end


% --- Executes on slider movement.
function slider5_Callback(hObject, eventdata, handles)
% hObject    handle to slider5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider


% --- Executes during object creation, after setting all properties.
function slider5_CreateFcn(hObject, eventdata, handles)
% hObject    handle to slider5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end


% --- Executes on slider movement.
function slider6_Callback(hObject, eventdata, handles)
% hObject    handle to slider6 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider


% --- Executes during object creation, after setting all properties.
function slider6_CreateFcn(hObject, eventdata, handles)
% hObject    handle to slider6 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end



function edit1_Callback(hObject, eventdata, handles)
% hObject    handle to edit1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit1 as text
%        str2double(get(hObject,'String')) returns contents of edit1 as a double


% --- Executes during object creation, after setting all properties.
function edit1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit2_Callback(hObject, eventdata, handles)
% hObject    handle to edit2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit2 as text
%        str2double(get(hObject,'String')) returns contents of edit2 as a double


% --- Executes during object creation, after setting all properties.
function edit2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit3_Callback(hObject, eventdata, handles)
% hObject    handle to edit3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit3 as text
%        str2double(get(hObject,'String')) returns contents of edit3 as a double


% --- Executes during object creation, after setting all properties.
function edit3_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit4_Callback(hObject, eventdata, handles)
% hObject    handle to edit4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit4 as text
%        str2double(get(hObject,'String')) returns contents of edit4 as a double


% --- Executes during object creation, after setting all properties.
function edit4_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit5_Callback(hObject, eventdata, handles)
% hObject    handle to edit5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit5 as text
%        str2double(get(hObject,'String')) returns contents of edit5 as a double


% --- Executes during object creation, after setting all properties.
function edit5_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit6_Callback(hObject, eventdata, handles)
% hObject    handle to edit6 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit6 as text
%        str2double(get(hObject,'String')) returns contents of edit6 as a double


% --- Executes during object creation, after setting all properties.
function edit6_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit6 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on slider movement.
function slider11_Callback(hObject, eventdata, handles)
ModelName = 'zzpt';
%get the angle
XM=get(handles.slider8,'value');
set(handles.edit8,'string',num2str(XM));

YM=get(handles.slider9,'value');
set(handles.edit9,'string',num2str(YM));

ZM=get(handles.slider10,'value');
set(handles.edit10,'string',num2str(ZM));
%
XM1=get(handles.slider11,'value');
set(handles.edit11,'string',num2str(XM1));

YM1=get(handles.slider12,'value');
set(handles.edit12,'string',num2str(YM1));

ZM1=get(handles.slider13,'value');
set(handles.edit13,'string',num2str(ZM1));
%Data transmission to simulink
set_param([ModelName '/Slider Gain15'],'Gain',num2str(XM));
set_param([ModelName '/Slider Gain7'],'Gain',num2str(YM));
set_param([ModelName '/Slider Gain16'],'Gain',num2str(ZM));
set_param([ModelName '/Slider Gain17'],'Gain',num2str(XM1));
set_param([ModelName '/Slider Gain12'],'Gain',num2str(YM1));
set_param([ModelName '/Slider Gain18'],'Gain',num2str(ZM1));
function slider11_CreateFcn(hObject, eventdata, handles)
% hObject    handle to slider11 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end



function edit11_Callback(hObject, eventdata, handles)
% hObject    handle to edit11 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit11 as text
%        str2double(get(hObject,'String')) returns contents of edit11 as a double


% --- Executes during object creation, after setting all properties.
function edit11_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit11 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on slider movement.
function slider12_Callback(hObject, eventdata, handles)
ModelName = 'zzpt';
%get the angle
XM=get(handles.slider8,'value');
set(handles.edit8,'string',num2str(XM));

YM=get(handles.slider9,'value');
set(handles.edit9,'string',num2str(YM));

ZM=get(handles.slider10,'value');
set(handles.edit10,'string',num2str(ZM));
%
XM1=get(handles.slider11,'value');
set(handles.edit11,'string',num2str(XM1));

YM1=get(handles.slider12,'value');
set(handles.edit12,'string',num2str(YM1));

ZM1=get(handles.slider13,'value');
set(handles.edit13,'string',num2str(ZM1));
%Data transmission to simulink
set_param([ModelName '/Slider Gain15'],'Gain',num2str(XM));
set_param([ModelName '/Slider Gain7'],'Gain',num2str(YM));
set_param([ModelName '/Slider Gain16'],'Gain',num2str(ZM));
set_param([ModelName '/Slider Gain17'],'Gain',num2str(XM1));
set_param([ModelName '/Slider Gain12'],'Gain',num2str(YM1));
set_param([ModelName '/Slider Gain18'],'Gain',num2str(ZM1));
function slider12_CreateFcn(hObject, eventdata, handles)
% hObject    handle to slider12 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end



function edit12_Callback(hObject, eventdata, handles)
% hObject    handle to edit12 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit12 as text
%        str2double(get(hObject,'String')) returns contents of edit12 as a double


% --- Executes during object creation, after setting all properties.
function edit12_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit12 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on slider movement.
function slider13_Callback(hObject, eventdata, handles)
ModelName = 'zzpt';
%get the angle
XM=get(handles.slider8,'value');
set(handles.edit8,'string',num2str(XM));

YM=get(handles.slider9,'value');
set(handles.edit9,'string',num2str(YM));

ZM=get(handles.slider10,'value');
set(handles.edit10,'string',num2str(ZM));
%
XM1=get(handles.slider11,'value');
set(handles.edit11,'string',num2str(XM1));

YM1=get(handles.slider12,'value');
set(handles.edit12,'string',num2str(YM1));

ZM1=get(handles.slider13,'value');
set(handles.edit13,'string',num2str(ZM1));
%Data transmission to simulink
set_param([ModelName '/Slider Gain15'],'Gain',num2str(XM));
set_param([ModelName '/Slider Gain7'],'Gain',num2str(YM));
set_param([ModelName '/Slider Gain16'],'Gain',num2str(ZM));
set_param([ModelName '/Slider Gain17'],'Gain',num2str(XM1));
set_param([ModelName '/Slider Gain12'],'Gain',num2str(YM1));
set_param([ModelName '/Slider Gain18'],'Gain',num2str(ZM1));
function slider13_CreateFcn(hObject, eventdata, handles)
% hObject    handle to slider13 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end



function edit13_Callback(hObject, eventdata, handles)
% hObject    handle to edit13 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit13 as text
%        str2double(get(hObject,'String')) returns contents of edit13 as a double


% --- Executes during object creation, after setting all properties.
function edit13_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit13 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on slider movement.
function slider8_Callback(hObject, eventdata, handles)
ModelName = 'zzpt';
%get the angle
XM=get(handles.slider8,'value');
set(handles.edit8,'string',num2str(XM));

YM=get(handles.slider9,'value');
set(handles.edit9,'string',num2str(YM));

ZM=get(handles.slider10,'value');
set(handles.edit10,'string',num2str(ZM));
%
XM1=get(handles.slider11,'value');
set(handles.edit11,'string',num2str(XM1));

YM1=get(handles.slider12,'value');
set(handles.edit12,'string',num2str(YM1));

ZM1=get(handles.slider13,'value');
set(handles.edit13,'string',num2str(ZM1));
%Data transmission to simulink
set_param([ModelName '/Slider Gain15'],'Gain',num2str(XM));
set_param([ModelName '/Slider Gain7'],'Gain',num2str(YM));
set_param([ModelName '/Slider Gain16'],'Gain',num2str(ZM));
set_param([ModelName '/Slider Gain17'],'Gain',num2str(XM1));
set_param([ModelName '/Slider Gain12'],'Gain',num2str(YM1));
set_param([ModelName '/Slider Gain18'],'Gain',num2str(ZM1));

function slider8_CreateFcn(hObject, eventdata, handles)
% hObject    handle to slider8 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end



function edit8_Callback(hObject, eventdata, handles)
% hObject    handle to edit8 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit8 as text
%        str2double(get(hObject,'String')) returns contents of edit8 as a double


% --- Executes during object creation, after setting all properties.
function edit8_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit8 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on slider movement.
function slider9_Callback(hObject, eventdata, handles)
ModelName = 'zzpt';
%get the angle
XM=get(handles.slider8,'value');
set(handles.edit8,'string',num2str(XM));

YM=get(handles.slider9,'value');
set(handles.edit9,'string',num2str(YM));

ZM=get(handles.slider10,'value');
set(handles.edit10,'string',num2str(ZM));
%
XM1=get(handles.slider11,'value');
set(handles.edit11,'string',num2str(XM1));

YM1=get(handles.slider12,'value');
set(handles.edit12,'string',num2str(YM1));

ZM1=get(handles.slider13,'value');
set(handles.edit13,'string',num2str(ZM1));
%Data transmission to simulink
set_param([ModelName '/Slider Gain15'],'Gain',num2str(XM));
set_param([ModelName '/Slider Gain7'],'Gain',num2str(YM));
set_param([ModelName '/Slider Gain16'],'Gain',num2str(ZM));
set_param([ModelName '/Slider Gain17'],'Gain',num2str(XM1));
set_param([ModelName '/Slider Gain12'],'Gain',num2str(YM1));
set_param([ModelName '/Slider Gain18'],'Gain',num2str(ZM1));
function slider9_CreateFcn(hObject, eventdata, handles)
% hObject    handle to slider9 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end



function edit9_Callback(hObject, eventdata, handles)
% hObject    handle to edit9 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit9 as text
%        str2double(get(hObject,'String')) returns contents of edit9 as a double


% --- Executes during object creation, after setting all properties.
function edit9_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit9 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on slider movement.
function slider10_Callback(hObject, eventdata, handles)
ModelName = 'zzpt';
%get the angle
XM=get(handles.slider8,'value');
set(handles.edit8,'string',num2str(XM));

YM=get(handles.slider9,'value');
set(handles.edit9,'string',num2str(YM));

ZM=get(handles.slider10,'value');
set(handles.edit10,'string',num2str(ZM));
%
XM1=get(handles.slider11,'value');
set(handles.edit11,'string',num2str(XM1));

YM1=get(handles.slider12,'value');
set(handles.edit12,'string',num2str(YM1));

ZM1=get(handles.slider13,'value');
set(handles.edit13,'string',num2str(ZM1));
%Data transmission to simulink
set_param([ModelName '/Slider Gain15'],'Gain',num2str(XM));
set_param([ModelName '/Slider Gain7'],'Gain',num2str(YM));
set_param([ModelName '/Slider Gain16'],'Gain',num2str(ZM));
set_param([ModelName '/Slider Gain17'],'Gain',num2str(XM1));
set_param([ModelName '/Slider Gain12'],'Gain',num2str(YM1));
set_param([ModelName '/Slider Gain18'],'Gain',num2str(ZM1));
function slider10_CreateFcn(hObject, eventdata, handles)
% hObject    handle to slider10 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end



function edit10_Callback(hObject, eventdata, handles)
% hObject    handle to edit10 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit10 as text
%        str2double(get(hObject,'String')) returns contents of edit10 as a double


% --- Executes during object creation, after setting all properties.
function edit10_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit10 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on slider movement.
function slider20_Callback(hObject, eventdata, handles)
ModelName = 'zzpt';
%get the angle
theta1=get(handles.slider20,'value');
set(handles.edit20,'string',num2str(theta1));
theta2=get(handles.slider21,'value');
set(handles.edit21,'string',num2str(theta2));
theta3=get(handles.slider22,'value');
set(handles.edit22,'string',num2str(theta3));
theta4=get(handles.slider23,'value');
set(handles.edit23,'string',num2str(theta4));
theta5=get(handles.slider24,'value');
set(handles.edit24,'string',num2str(theta5));
theta11=get(handles.slider26,'value');
set(handles.edit27,'string',num2str(theta11));
%Data transmission to simulink
set_param([ModelName '/Slider Gain'],'Gain',num2str(theta11));
set_param([ModelName '/Slider Gain1'],'Gain',num2str(theta1));
set_param([ModelName '/Slider Gain2'],'Gain',num2str(theta2));
set_param([ModelName '/Slider Gain3'],'Gain',num2str(theta3));
set_param([ModelName '/Slider Gain4'],'Gain',num2str(theta4));
set_param([ModelName '/Slider Gain5'],'Gain',num2str(theta5));
% --- Executes during object creation, after setting all properties.
function slider20_CreateFcn(hObject, eventdata, handles)
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end


% --- Executes on slider movement.
function slider21_Callback(hObject, eventdata, handles)
ModelName = 'zzpt';
%get the angle
theta1=get(handles.slider20,'value');
set(handles.edit20,'string',num2str(theta1));
theta2=get(handles.slider21,'value');
set(handles.edit21,'string',num2str(theta2));
theta3=get(handles.slider22,'value');
set(handles.edit22,'string',num2str(theta3));
theta4=get(handles.slider23,'value');
set(handles.edit23,'string',num2str(theta4));
theta5=get(handles.slider24,'value');
set(handles.edit24,'string',num2str(theta5));
theta11=get(handles.slider26,'value');
set(handles.edit27,'string',num2str(theta11));
%Data transmission to simulink
set_param([ModelName '/Slider Gain'],'Gain',num2str(theta11));
set_param([ModelName '/Slider Gain1'],'Gain',num2str(theta1));
set_param([ModelName '/Slider Gain2'],'Gain',num2str(theta2));
set_param([ModelName '/Slider Gain3'],'Gain',num2str(theta3));
set_param([ModelName '/Slider Gain4'],'Gain',num2str(theta4));
set_param([ModelName '/Slider Gain5'],'Gain',num2str(theta5));

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider


% --- Executes during object creation, after setting all properties.
function slider21_CreateFcn(hObject, eventdata, handles)
% hObject    handle to slider21 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end


% --- Executes on slider movement.
function slider22_Callback(hObject, eventdata, handles)
ModelName = 'zzpt';
%get the angle
theta1=get(handles.slider20,'value');
set(handles.edit20,'string',num2str(theta1));
theta2=get(handles.slider21,'value');
set(handles.edit21,'string',num2str(theta2));
theta3=get(handles.slider22,'value');
set(handles.edit22,'string',num2str(theta3));
theta4=get(handles.slider23,'value');
set(handles.edit23,'string',num2str(theta4));
theta5=get(handles.slider24,'value');
set(handles.edit24,'string',num2str(theta5));
theta11=get(handles.slider26,'value');
set(handles.edit27,'string',num2str(theta11));
%Data transmission to simulink
set_param([ModelName '/Slider Gain'],'Gain',num2str(theta11));
set_param([ModelName '/Slider Gain1'],'Gain',num2str(theta1));
set_param([ModelName '/Slider Gain2'],'Gain',num2str(theta2));
set_param([ModelName '/Slider Gain3'],'Gain',num2str(theta3));
set_param([ModelName '/Slider Gain4'],'Gain',num2str(theta4));
set_param([ModelName '/Slider Gain5'],'Gain',num2str(theta5));
% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider


% --- Executes during object creation, after setting all properties.
function slider22_CreateFcn(hObject, eventdata, handles)
% hObject    handle to slider22 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end


% --- Executes on slider movement.
function slider23_Callback(hObject, eventdata, handles)
ModelName = 'zzpt';
%get the angle
theta1=get(handles.slider20,'value');
set(handles.edit20,'string',num2str(theta1));
theta2=get(handles.slider21,'value');
set(handles.edit21,'string',num2str(theta2));
theta3=get(handles.slider22,'value');
set(handles.edit22,'string',num2str(theta3));
theta4=get(handles.slider23,'value');
set(handles.edit23,'string',num2str(theta4));
theta5=get(handles.slider24,'value');
set(handles.edit24,'string',num2str(theta5));
theta11=get(handles.slider26,'value');
set(handles.edit27,'string',num2str(theta11));
%Data transmission to simulink
set_param([ModelName '/Slider Gain'],'Gain',num2str(theta11));
set_param([ModelName '/Slider Gain1'],'Gain',num2str(theta1));
set_param([ModelName '/Slider Gain2'],'Gain',num2str(theta2));
set_param([ModelName '/Slider Gain3'],'Gain',num2str(theta3));
set_param([ModelName '/Slider Gain4'],'Gain',num2str(theta4));
set_param([ModelName '/Slider Gain5'],'Gain',num2str(theta5));
% --- Executes during object creation, after setting all properties.
function slider23_CreateFcn(hObject, eventdata, handles)
% hObject    handle to slider23 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end


% --- Executes on slider movement.
function slider24_Callback(hObject, eventdata, handles)
ModelName = 'zzpt';
%get the angle
theta1=get(handles.slider20,'value');
set(handles.edit20,'string',num2str(theta1));
theta2=get(handles.slider21,'value');
set(handles.edit21,'string',num2str(theta2));
theta3=get(handles.slider22,'value');
set(handles.edit22,'string',num2str(theta3));
theta4=get(handles.slider23,'value');
set(handles.edit23,'string',num2str(theta4));
theta5=get(handles.slider24,'value');
set(handles.edit24,'string',num2str(theta5));
theta11=get(handles.slider26,'value');
set(handles.edit27,'string',num2str(theta11));
%Data transmission to simulink
set_param([ModelName '/Slider Gain'],'Gain',num2str(theta11));
set_param([ModelName '/Slider Gain1'],'Gain',num2str(theta1));
set_param([ModelName '/Slider Gain2'],'Gain',num2str(theta2));
set_param([ModelName '/Slider Gain3'],'Gain',num2str(theta3));
set_param([ModelName '/Slider Gain4'],'Gain',num2str(theta4));
set_param([ModelName '/Slider Gain5'],'Gain',num2str(theta5));
% --- Executes during object creation, after setting all properties.
function slider24_CreateFcn(hObject, eventdata, handles)
% hObject    handle to slider24 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end


% --- Executes on slider movement.
function slider25_Callback(hObject, eventdata, handles)
% hObject    handle to slider25 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider


% --- Executes during object creation, after setting all properties.
function slider25_CreateFcn(hObject, eventdata, handles)
% hObject    handle to slider25 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end



function edit20_Callback(hObject, eventdata, handles)
% hObject    handle to edit20 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit20 as text
%        str2double(get(hObject,'String')) returns contents of edit20 as a double


% --- Executes during object creation, after setting all properties.
function edit20_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit20 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit21_Callback(hObject, eventdata, handles)
% hObject    handle to edit21 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit21 as text
%        str2double(get(hObject,'String')) returns contents of edit21 as a double


% --- Executes during object creation, after setting all properties.
function edit21_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit21 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit22_Callback(hObject, eventdata, handles)
% hObject    handle to edit22 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit22 as text
%        str2double(get(hObject,'String')) returns contents of edit22 as a double


% --- Executes during object creation, after setting all properties.
function edit22_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit22 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit23_Callback(hObject, eventdata, handles)
% hObject    handle to edit23 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit23 as text
%        str2double(get(hObject,'String')) returns contents of edit23 as a double


% --- Executes during object creation, after setting all properties.
function edit23_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit23 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit24_Callback(hObject, eventdata, handles)
% hObject    handle to edit24 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit24 as text
%        str2double(get(hObject,'String')) returns contents of edit24 as a double


% --- Executes during object creation, after setting all properties.
function edit24_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit24 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit25_Callback(hObject, eventdata, handles)
% hObject    handle to edit25 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit25 as text
%        str2double(get(hObject,'String')) returns contents of edit25 as a double


% --- Executes during object creation, after setting all properties.
function edit25_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit25 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in radiobutton1.
function radiobutton1_Callback(hObject, eventdata, handles)
value=get(handles.radiobutton1,'value');
if value==1
Gripper=-0.05;
else
Gripper=0.058;    
end
ModelName='zzpt';
set_param([ModelName '/Slider Gain6'],'Gain',num2str(Gripper));
% --- Executes on button press in radiobutton2.
function radiobutton2_Callback(hObject, eventdata, handles)
value=get(handles.radiobutton2,'value');
if value==1
Gripper1=0.12;
else
Gripper1=-0.12;    
end
ModelName='zzpt';
set_param([ModelName '/Slider Gain9'],'Gain',num2str(Gripper1));
% --- Executes on button press in radiobutton3.
function radiobutton3_Callback(hObject, eventdata, handles)
value=get(handles.radiobutton3,'value');
if value==1
Gripper2=0.12;
else
Gripper2=-0.120;    
end
ModelName='zzpt';
set_param([ModelName '/Slider Gain14'],'Gain',num2str(Gripper2));
function edit26_Callback(hObject, eventdata, handles)
% hObject    handle to edit26 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit26 as text
%        str2double(get(hObject,'String')) returns contents of edit26 as a double


% --- Executes during object creation, after setting all properties.
function edit26_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit26 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in pushbutton4.
function pushbutton4_Callback(hObject, eventdata, handles)
ModelName = 'zzpt';
%get the angle
CH=2;%������ֵ����·
set_param([ModelName '/Slider Gain8'],'Gain',num2str(CH));
theta1=180;
set(handles.edit20,'string',num2str(theta1));
theta2=180;
set(handles.edit21,'string',num2str(theta2));
theta3=180;
set(handles.edit22,'string',num2str(theta3));
theta4=0;
set(handles.edit23,'string',num2str(theta4));
theta5=81;
set(handles.edit24,'string',num2str(theta5));
theta11=0;
set(handles.edit27,'string',num2str(theta11));
%Data transmission to simulink
set_param([ModelName '/Slider Gain'],'Gain',num2str(theta11));
set_param([ModelName '/Slider Gain1'],'Gain',num2str(theta1));
set_param([ModelName '/Slider Gain2'],'Gain',num2str(theta2));
set_param([ModelName '/Slider Gain3'],'Gain',num2str(theta3));
set_param([ModelName '/Slider Gain4'],'Gain',num2str(theta4));
set_param([ModelName '/Slider Gain5'],'Gain',num2str(theta5));
set(handles.slider20,'value',theta1);
set(handles.slider21,'value',theta2);
set(handles.slider22,'value',theta3);
set(handles.slider23,'value',theta4);
set(handles.slider24,'value',theta5);
set(handles.slider26,'value',theta11);
% Palletizer
XM=0;
set(handles.edit8,'string',num2str(XM));

YM=0;
set(handles.edit9,'string',num2str(YM));

ZM=1.7;
set(handles.edit10,'string',num2str(ZM));
%
XM1=0;
set(handles.edit11,'string',num2str(XM1));

YM1=0;
set(handles.edit12,'string',num2str(YM1));

ZM1=-1;
set(handles.edit13,'string',num2str(ZM1));
%Data transmission to simulink
set_param([ModelName '/Slider Gain15'],'Gain',num2str(XM));
set_param([ModelName '/Slider Gain7'],'Gain',num2str(YM));
set_param([ModelName '/Slider Gain16'],'Gain',num2str(ZM));
set_param([ModelName '/Slider Gain17'],'Gain',num2str(XM1));
set_param([ModelName '/Slider Gain12'],'Gain',num2str(YM1));
set_param([ModelName '/Slider Gain18'],'Gain',num2str(ZM1));
% --- Executes on button press in pushbutton6.
function pushbutton6_Callback(hObject, eventdata, handles)
ModelName='zzpt';
CH=0;%������ֵ����·����ֵΪ1
set_param([ModelName '/Slider Gain8'],'Gain',num2str(CH));

% --- Executes on slider movement.
function slider26_Callback(hObject, eventdata, handles)
ModelName = 'zzpt';
%get the angle
theta1=get(handles.slider20,'value');
set(handles.edit20,'string',num2str(theta1));
theta2=get(handles.slider21,'value');
set(handles.edit21,'string',num2str(theta2));
theta3=get(handles.slider22,'value');
set(handles.edit22,'string',num2str(theta3));
theta4=get(handles.slider23,'value');
set(handles.edit23,'string',num2str(theta4));
theta5=get(handles.slider24,'value');
set(handles.edit24,'string',num2str(theta5));
theta11=get(handles.slider26,'value');
set(handles.edit27,'string',num2str(theta11));
%Data transmission to simulink
set_param([ModelName '/Slider Gain'],'Gain',num2str(theta11));
set_param([ModelName '/Slider Gain1'],'Gain',num2str(theta1));
set_param([ModelName '/Slider Gain2'],'Gain',num2str(theta2));
set_param([ModelName '/Slider Gain3'],'Gain',num2str(theta3));
set_param([ModelName '/Slider Gain4'],'Gain',num2str(theta4));
set_param([ModelName '/Slider Gain5'],'Gain',num2str(theta5));
% --- Executes during object creation, after setting all properties.
function slider26_CreateFcn(hObject, eventdata, handles)
% hObject    handle to slider26 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end



function edit27_Callback(hObject, eventdata, handles)
% hObject    handle to edit27 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit27 as text
%        str2double(get(hObject,'String')) returns contents of edit27 as a double


% --- Executes during object creation, after setting all properties.
function edit27_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit27 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in pushbutton7.
function pushbutton7_Callback(hObject, eventdata, handles)
% ModelName = 'zzpt';
% %get the angle
% CH=2;%������ֵ����·
% set_param([ModelName '/Slider Gain8'],'Gain',num2str(CH));
 cl = questdlg('�Ƿ�����ʾ������? ','ʾ��',...
            'Yes','No','Delete','Delete');
switch cl
    case 'Yes'
          quit cancel;
Guide=str2double(get(handles.edit27,'String'));
J1=str2double(get(handles.edit20,'String'));
J2=str2double(get(handles.edit21,'String'));
J3=str2double(get(handles.edit22,'String'));
J4=str2double(get(handles.edit23,'String'));
J5=str2double(get(handles.edit24,'String'));
Gripper=get(handles.radiobutton1,'value');% 1 FOR OPEN
Y=str2double(get(handles.edit12,'String'));
Gripper1=get(handles.radiobutton2,'value');
Y1=str2double(get(handles.edit9,'String'));
Gripper2=get(handles.radiobutton3,'value');
X=str2double(get(handles.edit8,'String'));
Z=str2double(get(handles.edit10,'String'));
X1=str2double(get(handles.edit11,'String'));
Z1=str2double(get(handles.edit13,'String'));
JointData=[Guide J1 J2 J3 J4 J5 Gripper Y Gripper1 Y1 Gripper2 X Z X1 Z1];
% plot��¼������
%  f = figure();
%  ax = axes('Parent',f); 
%  hold on
%  plot (ax, J1, 'Marker','o','LineStyle','-');
%  grid(ax, 'on')
%  rotate3d(ax, 'on')
msgbox('     �����Ѽ�¼--�����¼�������ʾ��')
dlmwrite('DataRecord.txt',JointData,'-append');
   case 'No'
      return;
      msgbox('δ���κ��޸�')
   case 'Delete'
        delete('DataRecord.txt')
        msgbox('��ɾ��ԭ��ʾ������')
        return;
end
